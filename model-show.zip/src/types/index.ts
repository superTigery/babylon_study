export type ConfigType = {
  model_path: string
  model_name: string
  env_path: string
  env_name: string
}
